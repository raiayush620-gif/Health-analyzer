import { GoogleGenAI } from '@google/generative-ai';
import EnergyRecord from '../models/EnergyRecord.js';

// Heuristic recommendations engine (Fallback when GEMINI_API_KEY is not provided or fails)
const getHeuristicInsight = (sleep, screenTime, waterIntake, stressLevel, energyScore) => {
  const points = [];

  if (energyScore > 85) {
    return `Phenomenal stats today! An energy score of ${energyScore}/100 shows excellent habits. Your sleep (${sleep}h) and stress management are highly synchronized. Maintain this rhythm by continuing your healthy hydration (${waterIntake} gl) and balanced screen breaks. You've hit the optimal wellness sweet spot!`;
  }

  // Sleep issues
  if (sleep < 6) {
    points.push(`Your sleep of ${sleep} hours is critically low. Chronic sleep deprivation elevates cortisol and hampers cognitive recovery. Prioritize a 7-8 hour sleep window tonight, and avoid caffeine after 2 PM.`);
  } else if (sleep < 7) {
    points.push(`Getting ${sleep} hours of sleep is slightly under the healthy 7-8 hour threshold. Extending your rest by just 30-60 minutes can dramatically improve your morning alertness.`);
  }

  // Dehydration
  if (waterIntake < 5) {
    points.push(`Dehydration is a hidden energy thief. Drinking only ${waterIntake} glasses of water causes blood volume to drop, forcing your heart to work harder. Aim for at least 8 glasses today.`);
  } else if (waterIntake < 8) {
    points.push(`Hydration is okay (${waterIntake} glasses), but increasing it to 8-10 glasses can clear up brain fog and increase metabolic energy.`);
  }

  // Screen time
  if (screenTime > 8) {
    points.push(`With ${screenTime} hours of screen time, eye strain and digital fatigue are draining your mental reserve. Try the 20-20-20 rule: every 20 minutes, look at something 20 feet away for 20 seconds.`);
  } else if (screenTime > 6) {
    points.push(`Your screen exposure is elevated (${screenTime}h). Dim your devices in the evening and block blue light to protect your melatonin production before sleep.`);
  }

  // Stress
  if (stressLevel > 7) {
    points.push(`A high stress level of ${stressLevel}/10 is severely impacting your energy. High stress locks your body in a fight-or-flight state, consuming glucose rapidly. Practice 5 minutes of box breathing now.`);
  } else if (stressLevel > 5) {
    points.push(`Moderate stress (${stressLevel}/10) is pulling down your score. A brisk 10-minute walk outside can help clear cortisol and restore focus.`);
  }

  if (points.length === 0) {
    return "Your daily parameters are balanced. Focus on maintaining consistency in your habits to keep your energy score stable.";
  }

  // Return a combination of the top recommendations
  return `Your energy score is ${energyScore}/100. Let's optimize: ${points.slice(0, 2).join(' ')}`;
};

// @desc    Get AI-based recommendations based on latest record
// @route   GET /api/records/ai-insight
// @access  Private
export const getAIInsight = async (req, res) => {
  try {
    // Find the latest record for the user
    const latestRecord = await EnergyRecord.findOne({ user: req.user._id }).sort({ date: -1 });

    if (!latestRecord) {
      return res.json({
        insight: "Welcome to Energy Analyzer! Enter your first health analysis on the 'Analysis' page to generate personalized AI recommendations.",
        hasData: false
      });
    }

    const { sleep, screenTime, waterIntake, stressLevel, energyScore } = latestRecord;

    // Check if GEMINI_API_KEY is available
    if (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'placeholder_key') {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
        const model = ai.getGenerativeModel({ model: "gemini-1.5-flash" });

        const prompt = `Act as an expert empathetic health coach. Based on the user's wellness metrics today: 
- Sleep: ${sleep} hours
- Screen Time: ${screenTime} hours
- Water Intake: ${waterIntake} glasses
- Stress Level: ${stressLevel}/10
- Calculated Energy Score: ${energyScore}/100

Generate a highly personalized daily recommendation (maximum 75 words) that explains what is draining their energy and suggests 2 immediate, actionable, and scientific changes they can make. Keep the tone inspiring, direct, and empathetic. Do not use markdown headers or lists.`;

        const result = await model.generateContent(prompt);
        const responseText = result.response.text();

        return res.json({
          insight: responseText.trim(),
          hasData: true,
          provider: 'Gemini AI'
        });
      } catch (aiError) {
        console.error('Gemini API call failed, falling back to heuristics:', aiError);
        // Fall through to heuristics
      }
    }

    // Heuristics Fallback
    const insight = getHeuristicInsight(sleep, screenTime, waterIntake, stressLevel, energyScore);
    res.json({
      insight,
      hasData: true,
      provider: 'Local Analysis Engine'
    });

  } catch (error) {
    console.error('AI Insight controller error:', error);
    res.status(500).json({ message: 'Server error generating AI insight' });
  }
};
