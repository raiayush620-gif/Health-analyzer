# PowerShell script to create a clean ZIP file of the Energy Analyzer MERN project.
# It excludes bulky folders like node_modules and builds.

$WorkspaceRoot = "c:\Users\i tech\Desktop\Energy Analyzer"
$TempDir = Join-Path $WorkspaceRoot "Energy_Analyzer_MERN_Temp"
$ZipFile = Join-Path $WorkspaceRoot "Energy_Analyzer_Fullstack.zip"

# Ensure old ZIP is removed
if (Test-Path $ZipFile) {
    Remove-Item $ZipFile -Force
}

# Ensure clean temp folder
if (Test-Path $TempDir) {
    Remove-Item $TempDir -Recurse -Force
}

# Create temp directory structure
New-Item -ItemType Directory -Path $TempDir -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $TempDir "client") -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $TempDir "server") -Force | Out-Null

Write-Host "Copying project files (excluding node_modules)..."

# Copy root files
Get-ChildItem -Path $WorkspaceRoot -File | Where-Object { 
    $_.Name -ne "Energy_Analyzer_Fullstack.zip" 
} | Copy-Item -Destination $TempDir

# Copy client folder contents (excluding node_modules and dist)
Get-ChildItem -Path (Join-Path $WorkspaceRoot "client") | Where-Object {
    $_.Name -ne "node_modules" -and $_.Name -ne "dist"
} | Copy-Item -Destination (Join-Path $TempDir "client") -Recurse -Force

# Copy server folder contents (excluding node_modules)
Get-ChildItem -Path (Join-Path $WorkspaceRoot "server") | Where-Object {
    $_.Name -ne "node_modules"
} | Copy-Item -Destination (Join-Path $TempDir "server") -Recurse -Force

# Create ZIP archive
Write-Host "Creating zip file at $ZipFile..."
Compress-Archive -Path "$TempDir\*" -DestinationPath $ZipFile -Force

# Clean up temp folder
Write-Host "Cleaning up temporary files..."
Remove-Item $TempDir -Recurse -Force

Write-Host "Success! Clean zip archive created at $ZipFile."
